AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
resource.AddFile( "materials/VGUI/entities/weapon_sawgun.vtf" )
resource.AddFile( "materials/VGUI/entities/weapon_sawgun.vmt" )
include( "shared.lua" )
include( "cl_init.lua" )

SWEP.Weight 			= 15;
SWEP.AutoSwitchTo 		= false;
SWEP.AutoSwitchFrom 	= false;
SWEP.FiresUnderwater 	= false;