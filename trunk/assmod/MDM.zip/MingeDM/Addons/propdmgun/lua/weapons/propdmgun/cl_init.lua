include('shared.lua')

SWEP.PrintName 		= "Saw/Flaming Barrel";
SWEP.Slot 			= 4;
SWEP.SlotPos 		= 8;