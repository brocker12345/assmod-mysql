SWEP.Author 		= "TotalMark";
SWEP.Contact 		= "totalmark@gmail.com";
SWEP.Purpose 		= "Kill/Dismember";
SWEP.Instructions 	= "Primary = Sawblade, Secondary = Flaming Barrel";
SWEP.Spawnable 		= false;
SWEP.AdminSpawnable = true;
SWEP.DrawCrosshair	= true;
SWEP.DrawAmmo 		= false;
SWEP.ViewModel 		= "models/Weapons/v_RPG.mdl";
SWEP.WorldModel 	= "models/Weapons/w_rocket_launcher.mdl";

SWEP.ViewModelFOV 	= 64;
SWEP.ReloadSound 	= "Rocket_Reload.wav";
SWEP.HoldType 		= "rpg";

SWEP.Proptime 		= 7.5;

SWEP.Primary.Ammo		    = "none"
//SWEP.Primary.ClipSize 		= 16;
SWEP.Primary.Automatic 		= true;
//SWEP.Primary.DefaultClip 	= 16;
SWEP.Primary.Recoil 		= 10;
SWEP.Primary.Spread 		= 0.4;
SWEP.Primary.Delay 			= 0.75;
//SWEP.Primary.TakeAmmo 		= 1;
SWEP.Primary.Sound 			= "Rocket_Launch_Single.wav";

SWEP.Secondary.Ammo		    = "none"
SWEP.Secondary.Recoil 		= 15;
SWEP.Secondary.Automatic 	= false;
SWEP.Secondary.Spread 		= 0.2;
//SWEP.Secondary.ClipSize 	= 1;
//SWEP.Secondary.DefaultClip 	= 3;
SWEP.Secondary.Delay 		= 1.6;
//SWEP.Secondary.TakeAmmo 	= 1;
SWEP.Secondary.Sound 		= "weapons/crossbow/fire1.wav";

function SWEP:throw_attack (model_file)
    local tr = self.Owner:GetEyeTrace();
    self.BaseClass.ShootEffects (self);
    if (!SERVER) then return end;
    local ent = ents.Create ("prop_physics");
    ent:Fire("kill","0",self.Proptime)
	ent:SetModel (model_file);
    ent:SetPos ( self.Owner:EyePos() + (self.Owner:GetAimVector() * 16) );
	ent:SetPhysicsAttacker( self.Owner )
	ent:Spawn();
	local phys = ent:GetPhysicsObject();
    local shot_length = tr.HitPos:Length();
    if (ent:GetModel() == "models/props_c17/oildrum001_explosive.mdl") then
		ent:Ignite(10);
		self.Weapon:EmitSound (self.Secondary.Sound);
		ent:SetKeyValue( "Damagetype", "0" )
		ent:SetKeyValue( "inertiaScale", "5" )
		ent:SetAngles (self.Owner:EyeAngles() + Angle(90,0,0));
		phys:AddAngleVelocity(Angle(0,0,9999));
		phys:ApplyForceCenter(self.Owner:GetAimVector():GetNormalized() * math.pow (shot_length, 5));
	else
		self.Weapon:EmitSound (self.Primary.Sound);
		ent:SetKeyValue( "Damagetype", "1" )
		ent:SetKeyValue( "inertiaScale", "20" )
		ent:SetAngles (self.Owner:EyeAngles());
		phys:AddAngleVelocity(Angle(100,100,10000));
		phys:SetVelocity(self.Owner:GetAimVector():GetNormalized() * math.pow (shot_length, 10));
	end
	cleanup.Add (self.Owner, "props", ent);
    undo.Create ("prop");
    undo.AddEntity (ent);
    undo.SetPlayer (self.Owner);
    undo.Finish();
	
end

function SWEP:Initialize()
    util.PrecacheSound(self.Primary.Sound)
	util.PrecacheSound(self.ReloadSound)
    util.PrecacheSound(self.Secondary.Sound)
    if ( SERVER ) then
       -- Sets how fast and how much shots an NPC shall do
	self:SetNPCFireRate(0.6);
	self:SetNPCMinBurst(1);
	self:SetNPCMaxBurst(16);
	-- Set holdtype, depending on NPCs, so it doesn't look too strange
	timer.Simple(0.2,
		function()
			if(not (self and self.SetWeaponHoldType)) then return end;
			if(self.Owner and self.Owner:IsValid() and self.Owner:IsNPC()) then
				local class = self.Owner:GetClass();
				if(class ~= "npc_metropolice") then
					self:SetWeaponHoldType("RPG");
				end
			end
		end
	);
	self:SetWeaponHoldType( self.HoldType );
   end
end

function SWEP:PrimaryAttack()
	if ( !self:CanPrimaryAttack() ) then return end
		//self:TakePrimaryAmmo(self.Primary.TakeAmmo)
		self:throw_attack ("models/props_junk/sawblade001a.mdl");
		self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
end

function SWEP:SecondaryAttack()
	if ( !self:CanSecondaryAttack() ) then return end
		//self:TakeSecondaryAmmo(self.Secondary.TakeAmmo)
		self:throw_attack ("models/props_c17/oildrum001_explosive.mdl");
		self.Weapon:SetNextSecondaryFire( CurTime() + self.Secondary.Delay )
end

function SWEP:Think()
end

function SWEP:Reload()
   self.Weapon:DefaultReload(ACT_VM_RELOAD)
   return true
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW);
   return true
end

function SWEP:Holster()
	return true
end

function SWEP:OnRemove()
end

function SWEP:OnRestore()
end

function SWEP:Precache()
end

function SWEP:OwnerChanged()
end
