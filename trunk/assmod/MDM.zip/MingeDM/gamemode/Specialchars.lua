function CheckSpecialCharacters( ply )
if ( ply:SteamID() == "STEAM_0:1:15909586" ) then
ply:PrintMessage( HUD_PRINTTALK, "Welcome back, VIP " .. ply:Nick() .. "\nYou connected under the IP: " .. ply:IPAddress() )
ply:SetTeam( 3 )
	    ply:Give( "weapon_physgun" )
ply:Give( "weapon_ar2" )
ply:Give( "propdmgun" )
return
end
end
