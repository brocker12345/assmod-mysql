AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "specialchars.lua" )
include( 'shared.lua' )
include( 'specialchars.lua' )
function GM:PlayerSpawn( ply )
 
    self.BaseClass:PlayerSpawn( ply )   
 
    ply:SetGravity( 0.75 )  
    ply:SetMaxHealth( 100, true )  
 
    ply:SetWalkSpeed( 325 )  
	ply:SetRunSpeed( 325 ) 
 
end

function GM:PlayerInitialSpawn( ply )
CheckSpecialCharacters( ply )
if ply:IsAdmin() then
mdmteam4( ply )
else
joining( ply )
RunConsoleCommand( "team_select" )
end
end

function GM:PlayerLoadout( ply )
if ply:Team() == 1 then
ply:Give( "propdmgun" )

elseif ply:Team() == 2 then
ply:Give( "weapon_ar2" )

elseif ply:Team() == 4 then
ply:Give( "propdmgun" )
ply:Give( "weapon_ar2" )
end
end
function mdmteam1( ply )
ply:UnSpectate()
ply:SetTeam( 1 )
ply:Spawn()
ply:PrintMessage( HUD_PRINTTALK, "|MingeDM Console| Welcome to the server PropDMer, " .. ply:Nick() )
end

function mdmteam2( ply )
ply:UnSpectate()
ply:SetTeam( 2 )
ply:Spawn()
ply:PrintMessage( HUD_PRINTTALK, "|MingeDM Console| Welcome to the server DMer, " .. ply:Nick() )
end

function mdmteam4( ply )
ply:SetTeam( 4 )
ply:Spawn()
	ply:PrintMessage( HUD_PRINTTALK, "|MingeDM Console| I recognize you as an admin, " .. ply:Nick() )
	end
concommand.Add( "PropDMer", mdmteam1 )
concommand.Add( "DMer", mdmteam2 )
function joining( ply )
ply:spectate( 5 )
ply:SetTeam( 4 )
end