GM.Name = "MingeDM"
GM.Author = "Nofear"
GM.Email = "Nofear.jonathan@hotmail.com"
GM.Website = "0m3gaserver.info"
DeriveGamemode( "base" )

team.SetUp( 1, "Prop DMers", Color( 125, 125, 125, 255 ) )
team.SetUp( 2, "DMer", Color( 255, 255, 255, 255 ) )
team.SetUp( 3, "V.I.P", Color( 148, 0, 211, 255 ) )
team.SetUp( 4, "Admin", Color( 255, 0 , 0, 255 ) )